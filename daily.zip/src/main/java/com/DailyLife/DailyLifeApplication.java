package com.DailyLife;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DailyLifeApplication {

	public static void main(String[] args) {
		SpringApplication.run(DailyLifeApplication.class, args);
	}

}
